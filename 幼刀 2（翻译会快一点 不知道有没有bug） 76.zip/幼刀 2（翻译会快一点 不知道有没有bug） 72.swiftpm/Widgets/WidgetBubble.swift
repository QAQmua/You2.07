// 📄 完整替换文件：Widgets/WidgetBubble.swift
import SwiftUI
import PhotosUI

final class BubbleWidgetPlugin: BaseWidgetPlugin {
    override class func register() {
        WidgetRegistry.shared.registerBubbleWidget()
    }
}

class ChatBubbleWidgetManager: ObservableObject {
    static let shared = ChatBubbleWidgetManager()
    
    private let photoIdKey = "App_Widget_2x2_Bubble_ImageID"
    private let firstKey = "App_Widget_2x2_Bubble_FirstText"
    private let secondKey = "App_Widget_2x2_Bubble_SecondText"
    private let addedKey = "App_Widget_2x2_Bubble_IsAdded"
    private let pageKey = "App_Widget_2x2_Bubble_PagePosition"
    private let rowKey = "App_Widget_2x2_Bubble_RowPosition"
    private let colKey = "App_Widget_2x2_Bubble_ColPosition"
    private let transparentKey = "App_Widget_2x2_Bubble_IsTransparent"
    
    private let bubbleColorKey = "App_Widget_2x2_Bubble_BgColor"
    private let textColorKey = "App_Widget_2x2_Bubble_TextColor"
    private let dateColorKey = "App_Widget_2x2_Bubble_DateColor"
    private let bubbleWeightKey = "App_Widget_2x2_Bubble_TextWeight"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    
    @Published var firstBubbleText: String {
        didSet {
            UserDefaults.standard.set(firstBubbleText, forKey: firstKey)
            AutoTranslationManager.shared.prewarm(text: firstBubbleText)
        }
    }
    
    @Published var secondBubbleText: String {
        didSet {
            UserDefaults.standard.set(secondBubbleText, forKey: secondKey)
            AutoTranslationManager.shared.prewarm(text: secondBubbleText)
        }
    }
    
    @Published var isTransparentBackground: Bool { didSet { UserDefaults.standard.set(isTransparentBackground, forKey: transparentKey) } }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: colKey) } }
    
    @Published var bubbleColorHex: String { didSet { UserDefaults.standard.set(bubbleColorHex, forKey: bubbleColorKey) } }
    @Published var textColorHex: String { didSet { UserDefaults.standard.set(textColorHex, forKey: textColorKey) } }
    @Published var dateColorHex: String { didSet { UserDefaults.standard.set(dateColorHex, forKey: dateColorKey) } }
    
    @Published var bubbleTextWeightName: String {
        didSet { UserDefaults.standard.set(bubbleTextWeightName, forKey: bubbleWeightKey) }
    }
    
    var bubbleColor: Color { Color(hex: bubbleColorHex) }
    var bubbleTextColor: Color { Color(hex: textColorHex) }
    var dateTextColor: Color { Color(hex: dateColorHex) }
    var bubbleTextWeight: Font.Weight { Font.Weight.from(name: bubbleTextWeightName) }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.firstBubbleText = UserDefaults.standard.string(forKey: firstKey) ?? "幼"
        self.secondBubbleText = UserDefaults.standard.string(forKey: secondKey) ?? "其实很可爱的哦..."
        self.isTransparentBackground = UserDefaults.standard.bool(forKey: transparentKey)
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.object(forKey: rowKey) != nil ? UserDefaults.standard.integer(forKey: rowKey) : 2
        self.widgetRow = min(max(0, rawRow), 4)
        
        let rawCol = UserDefaults.standard.integer(forKey: colKey)
        self.widgetCol = (rawCol > 0) ? 2 : 0
        
        self.bubbleColorHex = UserDefaults.standard.string(forKey: bubbleColorKey) ?? "#E5E5EA"
        self.textColorHex = UserDefaults.standard.string(forKey: textColorKey) ?? "#000000"
        self.dateColorHex = UserDefaults.standard.string(forKey: dateColorKey) ?? "#8E8E93"
        self.bubbleTextWeightName = UserDefaults.standard.string(forKey: bubbleWeightKey) ?? "medium"
        
        AutoTranslationManager.shared.prewarm(text: firstBubbleText)
        AutoTranslationManager.shared.prewarm(text: secondBubbleText)
    }
}

struct ChatBubbleWidget2x2View: View {
    @ObservedObject var manager: ChatBubbleWidgetManager = .shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    var imageData: Data? = nil
    var firstBubbleText: String = "幼"
    var secondBubbleText: String = "其实很可爱的哦..."
    var isTransparent: Bool = false
    var bubbleColor: Color = Color(UIColor.systemGray5)
    var bubbleTextColor: Color = .primary
    var dateTextColor: Color = Color.secondary.opacity(0.75)
    var bubbleTextWeight: Font.Weight = .medium
    var showDashedBorder: Bool = false
    
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    @State private var currentDate: Date = Date()
    private static let sharedFormatter = DateFormatter()
    
    private var formattedDate: String {
        Self.sharedFormatter.locale = Locale(identifier: lang.currentLanguage.localeIdentifier)
        switch lang.currentLanguage {
        case .simplifiedChinese, .traditionalChinese: Self.sharedFormatter.dateFormat = "M月d日 EEEE"
        case .english: Self.sharedFormatter.dateFormat = "EEEE, MMM d"
        case .japanese: Self.sharedFormatter.dateFormat = "M月d日(EEEE)"
        case .korean: Self.sharedFormatter.dateFormat = "M월 d일 EEEE"
        }
        return Self.sharedFormatter.string(from: currentDate)
    }
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    var body: some View {
        let s = uiScale // 🌟 注入全局放大系数
        
        ZStack(alignment: .topLeading) {
            VStack(alignment: .leading, spacing: 5 * s) {
                HStack {
                    Spacer()
                    Text(formattedDate)
                        .font(.system(size: 8.5 * s))
                        .fontWeight(appearance.systemFontWeight)
                        .foregroundColor(dateTextColor)
                        .lineLimit(1)
                    Spacer()
                }
                .padding(.top, -3 * s)
                
                HStack {
                    Text(translator.translate(firstBubbleText))
                        .font(.system(size: 10 * s))
                        .fontWeight(effectiveWeight(bubbleTextWeight))
                        .foregroundColor(bubbleTextColor)
                        .lineLimit(1)
                        .padding(.horizontal, 8 * s)
                        .padding(.vertical, 3 * s)
                        .background(bubbleColor)
                        .clipShape(Capsule())
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10 * s)
                
                HStack(alignment: .bottom, spacing: 6 * s) {
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                        Group {
                            let currentImage = manager.widgetImageData ?? imageData
                            if let data = currentImage, let uiImage = ImageBitmapCache.shared.image(from: data) {
                                Image(uiImage: uiImage).resizable().scaledToFill()
                            } else {
                                ZStack {
                                    Color(UIColor.systemGray6)
                                    Image(systemName: "photo")
                                        .font(.system(size: 24 * s))
                                        .foregroundColor(.secondary.opacity(0.5))
                                }
                            }
                        }
                        .frame(width: 114 * s, height: 64 * s)
                        .clipShape(RoundedRectangle(cornerRadius: 12 * s, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12 * s, style: .continuous)
                                .stroke(Color.primary.opacity(0.06), lineWidth: 0.8 * s)
                        )
                    }
                    .buttonStyle(.plain)
                    
                    ZStack {
                        Circle()
                            .fill(Color.primary.opacity(0.2))
                            .frame(width: 18 * s, height: 18 * s)
                        
                        Image(systemName: "arrowshape.turn.up.right.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 8.5 * s, height: 8.5 * s)
                            .foregroundColor(.white)
                            .offset(x: 0, y: -0.4 * s)
                    }
                    .padding(.bottom, 2 * s)
                    
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10 * s)
                
                HStack {
                    Text(translator.translate(secondBubbleText))
                        .font(.system(size: 9.5 * s))
                        .fontWeight(effectiveWeight(bubbleTextWeight))
                        .foregroundColor(bubbleTextColor)
                        .lineLimit(1)
                        .padding(.horizontal, 8 * s)
                        .padding(.vertical, 3.5 * s)
                        .background(bubbleColor)
                        .clipShape(Capsule())
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10 * s)
                .padding(.bottom, 6 * s)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(isTransparent ? Color.clear : Color(UIColor.secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(
                        isTransparent ? (showDashedBorder ? Color.secondary.opacity(0.4) : Color.clear) : Color.white.opacity(0.2),
                        style: StrokeStyle(lineWidth: 1 * s, dash: (isTransparent && showDashedBorder) ? [5 * s, 4 * s] : [])
                    )
            )
            .contentShape(Rectangle())
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.significantTimeChangeNotification).receive(on: DispatchQueue.main)) { _ in
            currentDate = Date()
        }
        .task(id: selectedPhotoItem) {
            if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) {
                    manager.widgetImageData = data
                }
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
    }
}

extension WidgetRegistry {
    func registerBubbleWidget() {
        let mgr = ChatBubbleWidgetManager.shared
        let s = uiScale // 🌟 注入全局放大系数
        registerWidget(
            id: "bubble",
            title: "widget_bubble_title",
            subtitle: "sub_bubble",
            badge: "2×2",
            manager: mgr,
            desktopView: {
                ChatBubbleWidget2x2View(
                    manager: mgr,
                    imageData: mgr.widgetImageData,
                    firstBubbleText: mgr.firstBubbleText,
                    secondBubbleText: mgr.secondBubbleText,
                    isTransparent: mgr.isTransparentBackground,
                    bubbleColor: mgr.bubbleColor,
                    bubbleTextColor: mgr.bubbleTextColor,
                    dateTextColor: mgr.dateTextColor,
                    bubbleTextWeight: mgr.bubbleTextWeight
                )
            },
            previewView: {
                ChatBubbleWidget2x2View(
                    manager: mgr,
                    imageData: mgr.widgetImageData,
                    firstBubbleText: mgr.firstBubbleText,
                    secondBubbleText: mgr.secondBubbleText,
                    isTransparent: mgr.isTransparentBackground,
                    bubbleColor: mgr.bubbleColor,
                    bubbleTextColor: mgr.bubbleTextColor,
                    dateTextColor: mgr.dateTextColor,
                    bubbleTextWeight: mgr.bubbleTextWeight
                ).frame(width: 160 * s, height: 160 * s)
            },
            editSheetView: { show in
                EditBubbleWidgetSheet(isPresented: show)
            }
        )
    }
}

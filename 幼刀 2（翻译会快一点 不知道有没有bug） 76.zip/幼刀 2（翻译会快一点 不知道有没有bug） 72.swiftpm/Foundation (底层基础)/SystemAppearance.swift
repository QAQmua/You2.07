import SwiftUI

// 📄 系统外观与显示设置管理
class SystemAppearance: ObservableObject {
    static let shared = SystemAppearance()
    
    @Published var isAuto: Bool = true { didSet { UserDefaults.standard.set(isAuto, forKey: "App_isAutoTheme") } }
    @Published var isDark: Bool = true { didSet { UserDefaults.standard.set(isDark, forKey: "App_isDarkTheme") } }
    @Published var hideHomeIndicator: Bool = false { didSet { UserDefaults.standard.set(hideHomeIndicator, forKey: "App_hideHomeIndicator") } }
    @Published var hideStatusBar: Bool = false { didSet { UserDefaults.standard.set(hideStatusBar, forKey: "App_hideStatusBar") } }
    @Published var systemFontWeightName: String = "regular" { didSet { UserDefaults.standard.set(systemFontWeightName, forKey: "App_systemFontWeightName") } }
    @Published var preferWidgetFontPriority: Bool = true { didSet { UserDefaults.standard.set(preferWidgetFontPriority, forKey: "App_preferWidgetFontPriority") } }
    
    var systemFontWeight: Font.Weight { Font.Weight.from(name: systemFontWeightName) }
    
    init() {
        if let autoVal = UserDefaults.standard.object(forKey: "App_isAutoTheme") as? Bool { self.isAuto = autoVal }
        if let darkVal = UserDefaults.standard.object(forKey: "App_isDarkTheme") as? Bool { self.isDark = darkVal }
        if let indicatorVal = UserDefaults.standard.object(forKey: "App_hideHomeIndicator") as? Bool { self.hideHomeIndicator = indicatorVal }
        if let statusVal = UserDefaults.standard.object(forKey: "App_hideStatusBar") as? Bool { self.hideStatusBar = statusVal }
        if let fontVal = UserDefaults.standard.string(forKey: "App_systemFontWeightName") { self.systemFontWeightName = fontVal }
        if let widgetPriorityVal = UserDefaults.standard.object(forKey: "App_preferWidgetFontPriority") as? Bool { self.preferWidgetFontPriority = widgetPriorityVal }
    }
    
    var colorScheme: ColorScheme? {
        if isAuto { return nil }
        return isDark ? .dark : .light
    }
}

extension View {
    @ViewBuilder
    func applyCustomAppearance(_ appearance: SystemAppearance) -> some View {
        if !appearance.isAuto {
            self.environment(\.colorScheme, appearance.isDark ? .dark : .light)
        } else {
            self
        }
    }
}
